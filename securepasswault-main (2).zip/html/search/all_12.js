var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['reliability_1',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
