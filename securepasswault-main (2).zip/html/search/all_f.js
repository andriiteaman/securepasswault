var searchData=
[
  ['nicknames_20logins_0',['3.2. Semantic Generation (Nicknames/Logins)',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
