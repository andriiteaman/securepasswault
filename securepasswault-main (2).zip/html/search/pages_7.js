var searchData=
[
  ['data_20integrity_20and_20authentication_0',['2.2. Data Integrity and Authentication',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['data_20persistence_20reliability_1',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['deployment_2',['4. Technical Stack and Deployment',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['deployment_20command_3',['Example Deployment Command',['../md__r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['deployment_20macos_20example_4',['Deployment (macOS Example)',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['derivation_20and_20anti_20brute_20force_20mechanism_5',['2.1. Key Derivation and Anti-Brute Force Mechanism',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
