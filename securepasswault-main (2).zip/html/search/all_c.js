var searchData=
[
  ['key_20derivation_20and_20anti_20brute_20force_20mechanism_0',['2.1. Key Derivation and Anti-Brute Force Mechanism',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
