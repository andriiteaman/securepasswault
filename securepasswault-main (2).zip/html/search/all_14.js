var searchData=
[
  ['technical_20stack_20and_20deployment_0',['4. Technical Stack and Deployment',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]]
];
