var searchData=
[
  ['1_20cryptographic_20generation_20passwords_0',['3.1. Cryptographic Generation (Passwords)',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['1_20key_20derivation_20and_20anti_20brute_20force_20mechanism_1',['2.1. Key Derivation and Anti-Brute Force Mechanism',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['1_20project_20overview_20and_20architecture_2',['1. Project Overview and Architecture',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
