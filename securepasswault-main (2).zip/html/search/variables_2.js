var searchData=
[
  ['vaultmanager_0',['vaultManager',['../class_main_window.html#ab33e4b5da36ef26bb063b3b4803ee98f',1,'MainWindow']]]
];
