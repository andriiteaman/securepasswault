var searchData=
[
  ['2_201_20key_20derivation_20and_20anti_20brute_20force_20mechanism_0',['2.1. Key Derivation and Anti-Brute Force Mechanism',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['2_202_20data_20integrity_20and_20authentication_1',['2.2. Data Integrity and Authentication',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['2_203_20data_20persistence_20reliability_2',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['2_20data_20integrity_20and_20authentication_3',['2.2. Data Integrity and Authentication',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['2_20security_20and_20cryptographic_20architecture_4',['2. Security and Cryptographic Architecture',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['2_20semantic_20generation_20nicknames_20logins_5',['3.2. Semantic Generation (Nicknames/Logins)',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
