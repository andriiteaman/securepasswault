var searchData=
[
  ['updateentry_0',['updateEntry',['../class_vault_backend.html#a219f10e7c3ca82a0b802233b8307cbcd',1,'VaultBackend']]],
  ['updatevaultlist_1',['updateVaultList',['../class_main_window.html#a7ecbc717f7f59b53ea5b8c56d3e7558c',1,'MainWindow']]]
];
