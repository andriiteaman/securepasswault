var searchData=
[
  ['decryptdata_0',['decryptData',['../class_vault_backend.html#ae65ef07ae665dbd8004d50e3a4de82bb',1,'VaultBackend']]],
  ['deleteentry_1',['deleteEntry',['../class_vault_backend.html#a97544c89c39d5a021878cdcc24b4559a',1,'VaultBackend']]],
  ['derivekey_2',['deriveKey',['../class_vault_backend.html#a61608f6a6d3e42d6d6cb1eb82a6e6a1a',1,'VaultBackend']]]
];
