var searchData=
[
  ['reliability_0',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
