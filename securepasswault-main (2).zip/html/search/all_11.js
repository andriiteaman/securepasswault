var searchData=
[
  ['passvault_20spv_0',['Secure PassVault (SPV)',['../md__r_e_a_d_m_e.html',1,'']]],
  ['passwords_1',['3.1. Cryptographic Generation (Passwords)',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['persistence_20reliability_2',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['project_20overview_20and_20architecture_3',['1. Project Overview and Architecture',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['promptformasterkey_4',['promptForMasterKey',['../class_main_window.html#a2da49242a5efb9ed05e41b82ae19b6fa',1,'MainWindow']]]
];
