var searchData=
[
  ['data_20integrity_20and_20authentication_0',['2.2. Data Integrity and Authentication',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['data_20persistence_20reliability_1',['2.3. Data Persistence Reliability',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['decryptdata_2',['decryptData',['../class_vault_backend.html#ae65ef07ae665dbd8004d50e3a4de82bb',1,'VaultBackend']]],
  ['deleteentry_3',['deleteEntry',['../class_vault_backend.html#a97544c89c39d5a021878cdcc24b4559a',1,'VaultBackend']]],
  ['deployment_4',['4. Technical Stack and Deployment',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['deployment_20command_5',['Example Deployment Command',['../md__r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['deployment_20macos_20example_6',['Deployment (macOS Example)',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['derivation_20and_20anti_20brute_20force_20mechanism_7',['2.1. Key Derivation and Anti-Brute Force Mechanism',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['derivekey_8',['deriveKey',['../class_vault_backend.html#a61608f6a6d3e42d6d6cb1eb82a6e6a1a',1,'VaultBackend']]]
];
