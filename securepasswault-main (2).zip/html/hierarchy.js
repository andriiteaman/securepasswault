var hierarchy =
[
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "VaultBackend", "class_vault_backend.html", null ]
    ] ]
];