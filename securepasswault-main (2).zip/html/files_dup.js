var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "vaultbackend.cpp", "vaultbackend_8cpp.html", "vaultbackend_8cpp" ],
    [ "vaultbackend.h", "vaultbackend_8h.html", "vaultbackend_8h" ]
];